# 2023_Winter_CSC_CIS_5
Dt. Lehr's Winter Intro to Programming Course
